<?php
/*
Template Name: 11 Menu
*/

get_header(); ?>

<?php get_template_part('inc/blocks/product-book'); ?>

<?php get_template_part('inc/blocks/blackboard'); ?>

<?php get_template_part('inc/blocks/opening-images'); ?>

<?php get_footer(); ?>